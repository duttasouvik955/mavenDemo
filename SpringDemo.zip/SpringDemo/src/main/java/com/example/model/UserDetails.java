package com.example.model;

public class UserDetails {
  private String ename;
  private String eid;
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public String getEid() {
	return eid;
}
public void setEid(String eid) {
	this.eid = eid;
}
  
}
