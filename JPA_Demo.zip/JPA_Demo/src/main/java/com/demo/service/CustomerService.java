package com.demo.service;
import java.util.List;

//import java.util.List;
import com.demo.model.Customer;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import com.demo.model.Customer;

import come.demo.repository.CustomerRepository;
public class CustomerService {
@Autowired
private CustomerRepository repository;
@Transactional
public List<Customer> getCustomer() {
	List<Customer> cust=repository.findAll();
	return cust;
}
@Transactional
public void addCustomer(Customer c1) {
	repository.save(c1);
}


}
