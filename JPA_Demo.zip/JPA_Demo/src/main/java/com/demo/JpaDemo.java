package com.demo;
import java.util.List;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.demo.model.Customer;
import com.demo.service.CustomerService;
@SpringBootApplication
public class JpaDemo {
    static ApplicationContext context=null;
    static CustomerService service=null;
	public static void main(String[] args) {
	  context = SpringApplication.run(JpaDemo.class, args);
		service=context.getBean(CustomerService.class);
		//CustomerService cs= new CustomerService();
		Customer c1=new Customer("c12","aab","efg");
		service.addCustomer(c1);
		/*cs.addCustomer(c1);
		List<Customer> list=cs.getCustomer();
		System.out.println(list);*/
	}

	

}
