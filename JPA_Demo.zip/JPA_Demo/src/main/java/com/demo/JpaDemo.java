package com.demo;
import java.util.List;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.demo.model.Customer;
import com.demo.service.CustomerService;
@SpringBootApplication
public class JpaDemo {

	public static void main(String[] args) {
		SpringApplication.run(JpaDemo.class, args);
		CustomerService cs= new CustomerService();
		Customer c1=new Customer("c11","abc","xyz");
		cs.addCustomer(c1);
		List<Customer> list=cs.getCustomer();
		System.out.println(list);
	}

	

}
