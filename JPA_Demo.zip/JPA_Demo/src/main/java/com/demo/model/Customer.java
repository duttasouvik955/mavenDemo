package com.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;

//import javax.persistence.Id;
@Entity
@Table(name="cust")
public class Customer {
@Id
@Column(name="cid", length=3)
private String id;
@Column(name="cname",length=25)
private String name;
@Column(name="ccity", length=20)
private String City;
public Customer() {
	super();
}
public Customer(String id, String name, String city) {
	super();
	this.id = id;
	this.name = name;
	City = city;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCity() {
	return City;
}
public void setCity(String city) {
	City = city;
}


}
