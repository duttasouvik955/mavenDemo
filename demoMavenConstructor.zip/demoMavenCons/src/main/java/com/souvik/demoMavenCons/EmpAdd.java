package com.souvik.demoMavenCons;

public class EmpAdd {
private String city;
private long zipcode;
public EmpAdd() {
	
}
public EmpAdd(String city,long zipcode) {
	this.city=city;
	this.zipcode=zipcode;
}
@Override
public String toString() {
	return "EmpAdd [city=" + city + ", zipcode=" + zipcode + "]";
}

}
