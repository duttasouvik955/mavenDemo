package com.souvik.demoMavenCons;

public class EmpDetails {
private String ename;
private String eid;
private EmpAdd ead;
public EmpDetails(){
	
}
public EmpDetails(String ename, String eid, EmpAdd ead) {
	super();
	this.ename = ename;
	this.eid = eid;
	this.ead = ead;
}
@Override
public String toString() {
	return "EmpDetails [ename=" + ename + ", eid=" + eid + ", ead=" + ead + "]";
}


}
