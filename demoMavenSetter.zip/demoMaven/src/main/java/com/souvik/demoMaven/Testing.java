package com.souvik.demoMaven;
import java.io.*;

import org.springframework.context.ApplicationContext;
import  org.springframework.context.support.ClassPathXmlApplicationContext;
//import org.springframework.beans.factory.BeanFactory;  
//import org.springframework.beans.factory.xml.XmlBeanFactory;  
//import org.springframework.core.io.*;  
public class Testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//setter injection
		ApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
		/*Setinj st=(Setinj)context.getBean("obj");
		System.out.println(st);*/
		
		//setter injection using p namespace
		/*Setinj st1=(Setinj)context.getBean("obj1");
		System.out.println(st1);*/
		
		//dependency injection using setters
		Setinj stj=(Setinj)context.getBean("obj2");
		String name= stj.getName();
		String id=stj.getId();
		String address=stj.getAdd().getLocation();
		System.out.println(name+"- "+id+ " is from "+address);
	}
	

}
