package com.souvik.demoMaven;

public class Setinj {
	private String name;
	private String id;
	Address add;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id=id;
	}
	public Address getAdd() {
		return add;
	}
	public void setAdd(Address add) {
		this.add=add;
	}
	@Override
	public String toString() {
		return name+" "+id;
	}
	

}
